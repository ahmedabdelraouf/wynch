<?php
namespace Dev\Application\Exceptions;

use Exception;

class InvalidDataException extends Exception
{
    //
}
