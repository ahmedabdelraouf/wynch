<?php return array (
  'users' => 'App\\Http\\Livewire\\Users',
);